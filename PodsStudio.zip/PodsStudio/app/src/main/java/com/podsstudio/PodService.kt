package com.podsstudio

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothA2dp
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings as AndroidSettings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Watches Bluetooth connection events for the saved earbuds, collects whatever battery data
 * Android genuinely exposes, and shows the popup. Runs as a low-power foreground service.
 */
@SuppressLint("MissingPermission")
class PodService : Service() {
    companion object {
        const val ACTION_PREVIEW = "com.podsstudio.PREVIEW"
        private const val CH_STATUS = "status"
        private const val CH_CONN = "connection"
        private const val ACTION_BATTERY = "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED"
        private const val EXTRA_BATTERY = "android.bluetooth.device.extra.BATTERY_LEVEL"
        private const val ACTION_VENDOR = "android.bluetooth.headset.action.VENDOR_SPECIFIC_HEADSET_EVENT"
        private const val EXTRA_CMD = "android.bluetooth.headset.extra.VENDOR_SPECIFIC_HEADSET_EVENT_CMD"
        private const val EXTRA_ARGS = "android.bluetooth.headset.extra.VENDOR_SPECIFIC_HEADSET_EVENT_ARGS"
        private const val CAT_APPLE = "android.bluetooth.headset.intent.category.companyid.76"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var repo: Repo
    private lateinit var overlay: Overlay
    private lateinit var gatt: GattBattery
    private var s = PodPrefs()
    private var lastTrigger = 0L
    private var popupJob: Job? = null
    private var synced = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        repo = Repo(this)
        overlay = Overlay(this)
        gatt = GattBattery(this) {
            LiveState.battery.value = it.coerceIn(0, 100)
            LiveState.source.value = "Bluetooth LE battery service"
        }
        createChannels()
        registerReceivers()
        scope.launch {
            repo.flow.collect {
                s = it
                getSystemService(NotificationManager::class.java).notify(1, foregroundNotification())
                if (!synced) { synced = true; syncConnected() }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, foregroundNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        if (intent?.action == ACTION_PREVIEW) scope.launch { showPopup(force = true) }
        return START_STICKY
    }

    override fun onDestroy() {
        try { unregisterReceiver(rx) } catch (_: Exception) {}
        try { unregisterReceiver(vendorRx) } catch (_: Exception) {}
        gatt.stop()
        overlay.hide()
        scope.cancel()
        super.onDestroy()
    }

    // ---- receivers -------------------------------------------------------------------------

    private fun isMine(i: Intent): Boolean {
        val d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        return d != null && d.address == s.deviceAddress
    }

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (!isMine(i)) return
            when (i.action) {
                BluetoothDevice.ACTION_ACL_CONNECTED -> onConnected()
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> onDisconnected()
                BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED -> when (i.getIntExtra(BluetoothProfile.EXTRA_STATE, -1)) {
                    BluetoothProfile.STATE_CONNECTED -> onConnected()
                    BluetoothProfile.STATE_DISCONNECTED -> onDisconnected()
                }
                ACTION_BATTERY -> {
                    val lvl = i.getIntExtra(EXTRA_BATTERY, -1)
                    if (lvl in 0..100) {
                        LiveState.battery.value = lvl
                        LiveState.source.value = "Android Bluetooth battery report"
                    }
                }
            }
        }
    }

    /** Apple-style battery report (+IPHONEACCEV) that some earbuds send over the headset profile. */
    private val vendorRx = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(c: Context, i: Intent) {
            if (!isMine(i)) return
            if (i.getStringExtra(EXTRA_CMD) != "+IPHONEACCEV") return
            val args = i.getSerializableExtra(EXTRA_ARGS) as? Array<*> ?: return
            var idx = 1
            while (idx + 1 < args.size) {
                val key = args[idx] as? Int
                val v = args[idx + 1] as? Int
                if (key == 1 && v != null && v in 0..9) {
                    LiveState.battery.value = ((v + 1) * 10).coerceAtMost(100)
                    LiveState.source.value = "Headset battery indicator"
                }
                idx += 2
            }
        }
    }

    private fun registerReceivers() {
        val f = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(BluetoothA2dp.ACTION_CONNECTION_STATE_CHANGED)
            addAction(ACTION_BATTERY)
        }
        registerReceiver(rx, f, Context.RECEIVER_EXPORTED)
        val v = IntentFilter(ACTION_VENDOR).apply { addCategory(CAT_APPLE) }
        registerReceiver(vendorRx, v, Context.RECEIVER_EXPORTED)
    }

    private fun syncConnected() {
        val a = getSystemService(BluetoothManager::class.java)?.adapter ?: return
        a.getProfileProxy(this, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                val on = proxy.connectedDevices.any { it.address == s.deviceAddress }
                LiveState.connected.value = on
                if (on) startGatt()
                a.closeProfileProxy(profile, proxy)
            }
            override fun onServiceDisconnected(profile: Int) {}
        }, BluetoothProfile.A2DP)
    }

    // ---- connection handling --------------------------------------------------------------

    private fun startGatt() {
        val addr = s.deviceAddress ?: return
        val a = getSystemService(BluetoothManager::class.java)?.adapter ?: return
        try { gatt.start(a.getRemoteDevice(addr)) } catch (_: Exception) {}
    }

    private fun onConnected() {
        LiveState.connected.value = true
        val now = SystemClock.elapsedRealtime()
        if (now - lastTrigger < 8000) return   // avoid duplicate popups
        lastTrigger = now
        startGatt()
        scope.launch { showPopup(force = false) }
    }

    private fun onDisconnected() {
        LiveState.connected.value = false
        LiveState.battery.value = null
        LiveState.source.value = null
        gatt.stop()
    }

    private suspend fun showPopup(force: Boolean) {
        val cur = repo.flow.first()
        s = cur
        val canOverlay = AndroidSettings.canDrawOverlays(this)
        val wantPopup = force || cur.autoPopup
        var shown = false
        if (wantPopup && canOverlay && !overlay.showing) shown = showOverlay(cur)
        if (!force && (cur.notifications || (wantPopup && !canOverlay))) postConnectedNotification(cur)
        if (force && !shown && !canOverlay) postConnectedNotification(cur)
    }

    private fun showOverlay(cur: PodPrefs): Boolean {
        val visible = mutableStateOf(true)
        val ok = overlay.show {
            val vis by visible
            PodsTheme(cur.theme) {
                ConnectionCard(cur, cur.deviceName ?: "Earbuds", vis) { openBattery() }
            }
        }
        if (!ok) return false
        popupJob?.cancel()
        popupJob = scope.launch {
            delay(cur.popupSecs * 1000L + (2200 / cur.animSpeed.coerceAtLeast(0.3f)).toLong())
            visible.value = false
            delay(450)
            overlay.hide()
        }
        return true
    }

    private fun openBattery() {
        popupJob?.cancel()
        overlay.hide()
        startActivity(
            Intent(this, MainActivity::class.java)
                .putExtra("screen", "battery")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
    }

    // ---- notifications ---------------------------------------------------------------------

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_STATUS, "Background monitoring", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_CONN, "Connection alerts", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun openIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java).putExtra("screen", "battery")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun foregroundNotification(): Notification =
        Notification.Builder(this, CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Watching for ${s.deviceName ?: "your earbuds"}")
            .setContentText("Popup appears when they connect")
            .setContentIntent(openIntent())
            .setOngoing(true)
            .build()

    private fun postConnectedNotification(cur: PodPrefs) {
        val bat = LiveState.battery.value
        val text = if (cur.showBattery && bat != null) "Connected · battery $bat%" else "Connected"
        val n = Notification.Builder(this, CH_CONN)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(cur.deviceName ?: "Earbuds")
            .setContentText(text)
            .setContentIntent(openIntent())
            .setAutoCancel(true)
            .setTimeoutAfter(cur.popupSecs * 1000L)
            .build()
        getSystemService(NotificationManager::class.java).notify(2, n)
    }
}
