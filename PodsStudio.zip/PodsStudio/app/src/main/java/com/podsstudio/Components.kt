package com.podsstudio

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PodsTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF0A84FF), background = Color(0xFF000000), surface = Color(0xFF1C1C1E),
        onBackground = Color.White, onSurface = Color.White,
        surfaceVariant = Color(0xFF2C2C2E), onSurfaceVariant = Color(0xFF9A9AA0)
    ) else lightColorScheme(
        primary = Color(0xFF0A7AFF), background = Color(0xFFF2F2F7), surface = Color.White,
        onBackground = Color(0xFF111111), onSurface = Color(0xFF111111),
        surfaceVariant = Color(0xFFE5E5EA), onSurfaceVariant = Color(0xFF6C6C70)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Page(title: String, onBack: (() -> Unit)?, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            else Spacer(Modifier.width(12.dp))
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 24.dp), content = content)
    }
}

@Composable
fun Card2(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    var m = modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surface)
    if (onClick != null) m = m.clickable(onClick = onClick)
    Column(m.padding(16.dp), content = content)
}

@Composable
fun SectionTitle(t: String) {
    Text(t, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 22.dp, bottom = 8.dp))
}

@Composable
fun Dim(t: String, modifier: Modifier = Modifier) {
    Text(t, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = modifier)
}

@Composable
fun SwatchRow(items: List<Swatch>, selected: Long, onPick: (Long) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        items.forEach { sw ->
            val sel = sw.argb == selected
            Column(Modifier.weight(1f).clickable { onPick(sw.argb) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    Modifier.size(46.dp).clip(CircleShape).background(Color(sw.argb))
                        .border(if (sel) 3.dp else 1.dp, if (sel) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.45f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    if (sel) Icon(Icons.Filled.Check, null, tint = if (Color(sw.argb).luminanceApprox() > 0.5f) Color.Black else Color.White)
                }
                Text(sw.name, fontSize = 10.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

private fun Color.luminanceApprox() = 0.299f * red + 0.587f * green + 0.114f * blue

@Composable
fun FinishChips(glossy: Boolean, onPick: (Boolean) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = !glossy, onClick = { onPick(false) }, label = { Text("Matte") })
        FilterChip(selected = glossy, onClick = { onPick(true) }, label = { Text("Glossy") })
    }
}

@Composable
fun ToggleRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium)
            if (sub != null) Dim(sub)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun BatteryBar(label: String, pct: Int) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Row {
            Text(label, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text("$pct%", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Box(Modifier.padding(top = 4.dp).fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
            Box(
                Modifier.fillMaxWidth(pct / 100f).fillMaxHeight().clip(RoundedCornerShape(4.dp))
                    .background(if (pct <= 20) Color(0xFFFF453A) else Color(0xFF34C759))
            )
        }
    }
}

/** The AirPods-style floating connection card. Used by the overlay window and the in-app preview. */
@Composable
fun ConnectionCard(s: PodPrefs, name: String, visible: Boolean, onTap: () -> Unit) {
    val lid = remember { Animatable(0f) }
    val rise = remember { Animatable(0f) }
    val info = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        playOpen(lid, rise, s.animSpeed)
        info.animateTo(1f, tween(450))
    }
    val connected by LiveState.connected.collectAsState()
    val bat by LiveState.battery.collectAsState()

    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(tween(450)) { -it } + fadeIn(tween(450)),
        exit = slideOutVertically(tween(350)) { -it } + fadeOut(tween(350))
    ) {
        Surface(
            shape = RoundedCornerShape(32.dp),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 18.dp,
            modifier = Modifier.fillMaxWidth().padding(16.dp).clickable { onTap() }
        ) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                PodScene(s, lid.value, rise.value, Modifier.fillMaxWidth().height(170.dp))
                Column(Modifier.graphicsLayer { alpha = info.value }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(name, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(if (connected) Color(0xFF34C759) else Color.Gray))
                        Spacer(Modifier.width(6.dp))
                        Text(if (connected) "Connected" else "Not connected", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (s.showBattery) {
                        val b = bat
                        if (b != null) BatteryBar("Earbuds", b)
                        else Text(
                            "Battery level not reported by this device",
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
            }
        }
    }
}
