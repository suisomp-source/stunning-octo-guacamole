package com.podsstudio

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

typealias Upd = ((PodPrefs) -> PodPrefs) -> Unit

// ------------------------------------------------------------------------------------------
// Welcome
// ------------------------------------------------------------------------------------------

@Composable
fun WelcomeScreen(s: PodPrefs, onAdd: () -> Unit) {
    val lid = remember { Animatable(0f) }
    val rise = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            playOpen(lid, rise, s.animSpeed)
            delay(2500)
            lid.animateTo(0f, tween(600)); rise.snapTo(0f)
            delay(600)
        }
    }
    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.weight(1f))
        PodScene(s, lid.value, rise.value, Modifier.fillMaxWidth().height(300.dp))
        Spacer(Modifier.height(24.dp))
        Text("Pods Studio", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Dim("Connect your S18 Pro earbuds and get an AirPods-style popup every time they connect.", Modifier.padding(top = 8.dp))
        Spacer(Modifier.weight(1f))
        Button(onClick = onAdd, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(28.dp)) {
            Text("Add New Earbuds", fontSize = 17.sp)
        }
    }
}

// ------------------------------------------------------------------------------------------
// Scanner
// ------------------------------------------------------------------------------------------

@Composable
fun ScannerScreen(onBack: () -> Unit, onPick: (Found) -> Unit) {
    val ctx = LocalContext.current
    val scanner = remember { BtScanner(ctx) }
    val list by scanner.found.collectAsState()
    val scanning by scanner.scanning.collectAsState()
    var btOn by remember { mutableStateOf(scanner.btOn) }
    val enable = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        btOn = scanner.btOn
        if (btOn) scanner.start()
    }
    DisposableEffect(Unit) {
        if (scanner.btOn) scanner.start()
        onDispose { scanner.stop() }
    }
    Page("Add Earbuds", onBack) {
        Dim("Put your S18 Pro earbuds in pairing mode (take them out of the case and hold until the light flashes).")
        Spacer(Modifier.height(12.dp))
        if (!scanner.supported) {
            Card2 { Text("This phone has no Bluetooth adapter.") }
        } else if (!btOn) {
            Card2 {
                Text("Bluetooth is off", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Button(onClick = { enable.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) }) { Text("Turn on Bluetooth") }
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (scanning) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Text(if (scanning) "Searching…" else "Scan finished", Modifier.weight(1f))
                TextButton(onClick = { scanner.start() }, enabled = !scanning) { Text("Scan again") }
            }
            Spacer(Modifier.height(8.dp))
            if (list.isEmpty()) Dim("No devices found yet.")
            list.forEach { f ->
                val isS18 = f.name?.contains("S18", ignoreCase = true) == true
                Card2(Modifier.padding(vertical = 4.dp), onClick = { onPick(f) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(f.name ?: "Unnamed device", fontWeight = FontWeight.SemiBold, color = if (isS18) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                            Dim(f.address + (if (f.bonded) " · Paired" else ""))
                        }
                        if (f.rssi != null) Dim("${f.rssi} dBm")
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------
// Pairing (uses Android's own pairing dialog via BluetoothDevice.createBond)
// ------------------------------------------------------------------------------------------

@SuppressLint("MissingPermission")
@Composable
fun PairingScreen(dev: Found?, onDone: (Found) -> Unit, onBack: () -> Unit) {
    if (dev == null) { LaunchedEffect(Unit) { onBack() }; return }
    val ctx = LocalContext.current
    var state by remember { mutableStateOf(if (dev.bonded) "bonded" else "pairing") }
    var attempt by remember { mutableIntStateOf(0) }

    DisposableEffect(dev.address, attempt) {
        val adapter = ctx.getSystemService(BluetoothManager::class.java).adapter
        val remote = adapter.getRemoteDevice(dev.address)
        val rx = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                if (d?.address != dev.address) return
                when (i.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, -1)) {
                    BluetoothDevice.BOND_BONDED -> state = "bonded"
                    BluetoothDevice.BOND_NONE -> state = "failed"
                }
            }
        }
        ctx.registerReceiver(rx, IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED), Context.RECEIVER_EXPORTED)
        adapter.cancelDiscovery()
        when (remote.bondState) {
            BluetoothDevice.BOND_BONDED -> state = "bonded"
            BluetoothDevice.BOND_NONE -> { state = "pairing"; if (!remote.createBond()) state = "failed" }
        }
        onDispose { try { ctx.unregisterReceiver(rx) } catch (_: Exception) {} }
    }
    LaunchedEffect(state) {
        if (state == "bonded") { delay(900); onDone(dev) }
    }

    val t = rememberInfiniteTransition(label = "pulse")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing), RepeatMode.Restart), label = "p")
    val ring = MaterialTheme.colorScheme.primary

    Page("Pairing", onBack) {
        Spacer(Modifier.height(24.dp))
        Box(Modifier.fillMaxWidth().height(240.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                if (state == "pairing") for (k in 0..2) {
                    val f = (p + k / 3f) % 1f
                    drawCircle(ring.copy(alpha = (1f - f) * 0.5f), radius = size.minDimension * (0.2f + 0.3f * f), center = Offset(size.width / 2, size.height / 2), style = Stroke(width = 4f))
                }
                drawCircle(if (state == "failed") Color(0xFFFF453A) else if (state == "bonded") Color(0xFF34C759) else ring, radius = size.minDimension * 0.14f, center = Offset(size.width / 2, size.height / 2))
            }
        }
        Text(dev.name ?: "Earbuds", fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Dim(
            when (state) {
                "bonded" -> "Paired. Saving your earbuds…"
                "failed" -> "Pairing failed or was cancelled. Make sure the earbuds are in pairing mode and try again."
                else -> "Confirm the pairing request that Android shows."
            },
            Modifier.fillMaxWidth().padding(top = 8.dp)
        )
        if (state == "failed") {
            Spacer(Modifier.height(16.dp))
            Button(onClick = { attempt++ }, modifier = Modifier.fillMaxWidth()) { Text("Try again") }
        }
    }
}

// ------------------------------------------------------------------------------------------
// Dashboard
// ------------------------------------------------------------------------------------------

@Composable
fun DashboardScreen(s: PodPrefs, go: (Screen) -> Unit, overlayOk: Boolean, onGrantOverlay: () -> Unit) {
    val lid = remember { Animatable(0f) }
    val rise = remember { Animatable(0f) }
    var replay by remember { mutableIntStateOf(0) }
    LaunchedEffect(replay) { playOpen(lid, rise, s.animSpeed) }
    val connected by LiveState.connected.collectAsState()
    val bat by LiveState.battery.collectAsState()

    Page("Pods Studio", null) {
        PodScene(s, lid.value, rise.value, Modifier.fillMaxWidth().height(250.dp).clickable { replay++ })
        Text(s.deviceName ?: "Earbuds", fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).clip(RoundedCornerShape(5.dp)).background(if (connected) Color(0xFF34C759) else Color.Gray))
            Spacer(Modifier.width(6.dp))
            Dim(if (connected) "Connected" else "Not connected")
            if (s.showBattery && bat != null) Dim("  ·  Battery $bat%")
        }
        if (s.autoPopup && !overlayOk) {
            Spacer(Modifier.height(16.dp))
            Card2 {
                Text("Allow popup over other apps", fontWeight = FontWeight.SemiBold)
                Dim("Without this permission you will get a notification instead of the floating card.", Modifier.padding(vertical = 6.dp))
                Button(onClick = onGrantOverlay) { Text("Grant permission") }
            }
        }
        Spacer(Modifier.height(16.dp))
        listOf(
            Triple("Customization Studio", "Style, colour and finish", Screen.Studio),
            Triple("Animation Preview", "Replay the connection popup", Screen.Preview),
            Triple("Battery", "What Android reports", Screen.Battery),
            Triple("Devices", "Manage saved earbuds", Screen.Devices),
            Triple("Settings", "Popup, theme, notifications", Screen.Settings)
        ).forEach { (t, sub, scr) ->
            Card2(Modifier.padding(vertical = 4.dp), onClick = { go(scr) }) {
                Text(t, fontWeight = FontWeight.SemiBold)
                Dim(sub)
            }
        }
    }
}

// ------------------------------------------------------------------------------------------
// Customization studio
// ------------------------------------------------------------------------------------------

@Composable
private fun OpenClosedPreview(s: PodPrefs) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            PodScene(s, 0f, 0f, Modifier.fillMaxWidth().height(150.dp))
            Dim("Closed")
        }
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            PodScene(s, 1f, 1f, Modifier.fillMaxWidth().height(150.dp))
            Dim("Open")
        }
    }
}

@Composable
fun StudioScreen(s: PodPrefs, upd: Upd, onBack: () -> Unit, onCase: () -> Unit) {
    Page("Customization Studio", onBack) {
        Card2 { OpenClosedPreview(s) }
        SectionTitle("Style")
        PodStyle.entries.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { st ->
                    val sel = st == s.style
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface)
                            .border(if (sel) 2.dp else 0.dp, if (sel) MaterialTheme.colorScheme.primary else Color.Transparent, RoundedCornerShape(20.dp))
                            .clickable { upd { it.copy(style = st) } }.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        PodScene(s.copy(style = st), 1f, 1f, Modifier.fillMaxWidth().height(90.dp))
                        Text(st.label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(st.blurb, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        SectionTitle("Colour")
        SwatchRow(PodColor.entries.map { Swatch(it.label, it.argb) }, s.podColor.argb) { v ->
            upd { it.copy(podColor = PodColor.entries.first { c -> c.argb == v }) }
        }
        SectionTitle("Earbud finish")
        FinishChips(s.podGlossy) { g -> upd { it.copy(podGlossy = g) } }
        Spacer(Modifier.height(20.dp))
        Button(onClick = onCase, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(26.dp)) {
            Text("Charging case customization")
        }
        Dim("Visual customization only. It does not change your S18 Pro hardware.", Modifier.padding(top = 12.dp))
    }
}

@Composable
fun CaseStudioScreen(s: PodPrefs, upd: Upd, onBack: () -> Unit) {
    Page("Charging Case", onBack) {
        Card2 { OpenClosedPreview(s) }
        Spacer(Modifier.height(8.dp))
        ToggleRow("Match earbuds", "Case exterior and lid follow the earbud colour", s.matchCase) { v -> upd { it.copy(matchCase = v) } }
        if (!s.matchCase) {
            SectionTitle("Case exterior")
            SwatchRow(CASE_COLORS, s.caseExt) { v -> upd { it.copy(caseExt = v) } }
            SectionTitle("Lid")
            SwatchRow(CASE_COLORS, s.caseLid) { v -> upd { it.copy(caseLid = v) } }
        }
        SectionTitle("Case interior")
        SwatchRow(INTERIORS, s.caseInt) { v -> upd { it.copy(caseInt = v) } }
        SectionTitle("LED indicator")
        SwatchRow(LEDS, s.led) { v -> upd { it.copy(led = v) } }
        SectionTitle("Case finish")
        FinishChips(s.caseGlossy) { g -> upd { it.copy(caseGlossy = g) } }
    }
}

// ------------------------------------------------------------------------------------------
// Animation preview
// ------------------------------------------------------------------------------------------

@Composable
fun PreviewScreen(s: PodPrefs, upd: Upd, onBack: () -> Unit) {
    val lid = remember { Animatable(0f) }
    val rise = remember { Animatable(0f) }
    var replay by remember { mutableIntStateOf(0) }
    var cardKey by remember { mutableIntStateOf(0) }
    var speed by remember(s.animSpeed) { mutableFloatStateOf(s.animSpeed) }
    LaunchedEffect(replay) { playOpen(lid, rise, speed) }

    Page("Animation Preview", onBack) {
        Card2 { PodScene(s, lid.value, rise.value, Modifier.fillMaxWidth().height(260.dp)) }
        Spacer(Modifier.height(12.dp))
        Button(onClick = { replay++ }, modifier = Modifier.fillMaxWidth()) { Text("Replay animation") }
        SectionTitle("Animation speed  ${"%.1f".format(speed)}x")
        Slider(value = speed, onValueChange = { speed = it }, onValueChangeFinished = { upd { it.copy(animSpeed = speed) } }, valueRange = 0.5f..2f)
        SectionTitle("Popup card")
        OutlinedButton(onClick = { cardKey++ }, modifier = Modifier.fillMaxWidth()) { Text("Show popup card preview") }
        if (cardKey > 0) key(cardKey) {
            ConnectionCard(s, s.deviceName ?: "Earbuds", true) {}
        }
    }
}

// ------------------------------------------------------------------------------------------
// Battery
// ------------------------------------------------------------------------------------------

@Composable
private fun Tile(label: String, value: String, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Dim(label)
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
fun BatteryScreen(s: PodPrefs, onBack: () -> Unit) {
    val connected by LiveState.connected.collectAsState()
    val bat by LiveState.battery.collectAsState()
    val src by LiveState.source.collectAsState()
    Page("Battery", onBack) {
        Text(s.deviceName ?: "Earbuds", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Dim(if (connected) "Connected" else "Not connected")
        Spacer(Modifier.height(16.dp))
        if (s.showBattery) {
            Card2 {
                Text("Reported battery", fontWeight = FontWeight.SemiBold)
                val b = bat
                if (b != null) {
                    BatteryBar("Earbuds", b)
                    Dim("Source: ${src ?: "Android"}", Modifier.padding(top = 8.dp))
                } else {
                    Dim("Your earbuds have not reported a battery level to Android.", Modifier.padding(top = 6.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Tile("Left", "—", Modifier.weight(1f))
                Tile("Right", "—", Modifier.weight(1f))
                Tile("Case", "—", Modifier.weight(1f))
            }
            Dim(
                "Generic earbuds like the S18 Pro normally report at most one combined level, and never the case, " +
                    "because the case has no Bluetooth link. Separate left, right and case values appear only if the device sends them; " +
                    "this app never estimates or invents a value.",
                Modifier.padding(top = 12.dp)
            )
        } else {
            Dim("Battery information is hidden. Turn it on in Settings.")
        }
    }
}

// ------------------------------------------------------------------------------------------
// Devices
// ------------------------------------------------------------------------------------------

@Composable
fun DevicesScreen(s: PodPrefs, upd: Upd, onBack: () -> Unit, onAdd: () -> Unit, onForget: () -> Unit) {
    val ctx = LocalContext.current
    Page("Devices", onBack) {
        Card2 {
            Text("Saved earbuds", fontWeight = FontWeight.SemiBold)
            Text(s.deviceName ?: "None", fontSize = 20.sp, modifier = Modifier.padding(top = 6.dp))
            Dim(s.deviceAddress ?: "No device saved")
        }
        Spacer(Modifier.height(12.dp))
        Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) { Text("Add or change earbuds") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { ctx.startActivity(Intent(AndroidSettings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }, modifier = Modifier.fillMaxWidth()) {
            Text("Open Bluetooth settings")
        }
        if (s.deviceAddress != null) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onForget, modifier = Modifier.fillMaxWidth()) { Text("Forget in this app", color = Color(0xFFFF453A)) }
            Dim("To fully unpair, remove the device in Android's Bluetooth settings.", Modifier.padding(top = 8.dp))
        }
    }
}

// ------------------------------------------------------------------------------------------
// Settings
// ------------------------------------------------------------------------------------------

@Composable
fun SettingsScreen(
    s: PodPrefs, upd: Upd, repo: Repo, overlayOk: Boolean,
    onBack: () -> Unit, onDevices: () -> Unit, onGrantOverlay: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var secs by remember(s.popupSecs) { mutableFloatStateOf(s.popupSecs.toFloat()) }
    var speed by remember(s.animSpeed) { mutableFloatStateOf(s.animSpeed) }
    Page("Settings", onBack) {
        Card2 {
            ToggleRow("Automatic popup", "Show the card when your earbuds connect", s.autoPopup) { v -> upd { it.copy(autoPopup = v) } }
            if (!overlayOk) {
                TextButton(onClick = onGrantOverlay) { Text("Allow display over other apps") }
            }
            HorizontalDivider()
            Text("Popup duration  ${secs.toInt()} s", modifier = Modifier.padding(top = 12.dp), fontWeight = FontWeight.Medium)
            Slider(value = secs, onValueChange = { secs = it }, onValueChangeFinished = { upd { it.copy(popupSecs = secs.toInt()) } }, valueRange = 3f..15f, steps = 11)
            Text("Animation speed  ${"%.1f".format(speed)}x", fontWeight = FontWeight.Medium)
            Slider(value = speed, onValueChange = { speed = it }, onValueChangeFinished = { upd { it.copy(animSpeed = speed) } }, valueRange = 0.5f..2f)
            HorizontalDivider()
            ToggleRow("Show battery information", null, s.showBattery) { v -> upd { it.copy(showBattery = v) } }
            ToggleRow("Connection notifications", "Also post a notification on connect", s.notifications) { v -> upd { it.copy(notifications = v) } }
        }
        SectionTitle("Theme")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("System", "Light", "Dark").forEachIndexed { i, l ->
                FilterChip(selected = s.theme == i, onClick = { upd { it.copy(theme = i) } }, label = { Text(l) })
            }
        }
        SectionTitle("Selected device")
        Card2(onClick = onDevices) {
            Text(s.deviceName ?: "None", fontWeight = FontWeight.SemiBold)
            Dim(s.deviceAddress ?: "Tap to add earbuds")
        }
        SectionTitle("Saved customization")
        Card2 {
            Dim("${s.style.label} · ${s.podColor.label} · ${if (s.podGlossy) "Glossy" else "Matte"}")
            Dim("Case: ${if (s.matchCase) "matches earbuds" else "custom"} · ${if (s.caseGlossy) "Glossy" else "Matte"}", Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { scope.launch { repo.resetCustomization() } }) { Text("Reset customization") }
        }
        SectionTitle("Test")
        OutlinedButton(
            onClick = {
                try {
                    ContextCompat.startForegroundService(ctx, Intent(ctx, PodService::class.java).setAction(PodService.ACTION_PREVIEW))
                } catch (_: Exception) {}
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = s.deviceAddress != null
        ) { Text("Preview popup over other apps") }
        Dim("This only previews the design. Real popups appear only when your earbuds actually connect.", Modifier.padding(top = 8.dp))
    }
}
