package com.podsstudio

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationVector1D
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.min

// ---------------------------------------------------------------------------------------------
// Animation timeline shared by the popup, dashboard and preview screens
// ---------------------------------------------------------------------------------------------

suspend fun playOpen(lid: Animatable<Float, AnimationVector1D>, rise: Animatable<Float, AnimationVector1D>, speed: Float) {
    val sp = speed.coerceIn(0.3f, 3f)
    lid.snapTo(0f)
    rise.snapTo(0f)
    delay((300 / sp).toLong())
    coroutineScope {
        launch { lid.animateTo(1f, tween((750 / sp).toInt(), easing = FastOutSlowInEasing)) }
        launch {
            delay((520 / sp).toLong())
            rise.animateTo(1f, tween((900 / sp).toInt(), easing = FastOutSlowInEasing))
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Colour helpers
// ---------------------------------------------------------------------------------------------

fun Color.lighten(f: Float): Color = lerp(this, Color.White, f)
fun Color.darken(f: Float): Color = lerp(this, Color.Black, f)
private fun Color.shade(f: Float): Color = if (luminance() < 0.2f) lighten(f * 0.5f) else darken(f)
private fun mix(a: Float, b: Float, t: Float) = a + (b - a) * t

private fun matBrush(c: Color, glossy: Boolean, y0: Float, y1: Float): Brush = Brush.verticalGradient(
    colors = if (glossy) listOf(c.lighten(0.40f), c, c.darken(0.35f))
    else listOf(c.lighten(0.10f), c, c.darken(0.16f)),
    startY = y0, endY = y1
)

// ---------------------------------------------------------------------------------------------
// Public composable
// ---------------------------------------------------------------------------------------------

/** lid: 0 = closed, 1 = fully open. rise: 0 = earbuds in case, 1 = floating above it. */
@Composable
fun PodScene(s: PodPrefs, lid: Float, rise: Float, modifier: Modifier = Modifier) {
    Canvas(modifier) { drawScene(s, lid, rise) }
}

private class CaseSpec(val w: Float, val h: Float, val r: Float, val lid: Float)

private fun spec(s: PodStyle) = when (s) {
    PodStyle.ORIGINAL -> CaseSpec(0.54f, 0.36f, 0.090f, 0.38f)
    PodStyle.PRO -> CaseSpec(0.58f, 0.32f, 0.140f, 0.38f)
    PodStyle.GEN3 -> CaseSpec(0.58f, 0.32f, 0.120f, 0.38f)
    PodStyle.MAX -> CaseSpec(0.50f, 0.30f, 0.060f, 0.42f)
}

private fun podHeight(s: PodStyle) = when (s) {
    PodStyle.ORIGINAL -> 0.22f
    PodStyle.PRO -> 0.17f
    PodStyle.GEN3 -> 0.18f
    PodStyle.MAX -> 0.34f
}

// ---------------------------------------------------------------------------------------------
// Scene
// ---------------------------------------------------------------------------------------------

private fun DrawScope.drawScene(st: PodPrefs, open: Float, rise: Float) {
    val u = min(size.width, size.height * 1.3f)
    val cx = size.width / 2f
    val sp = spec(st.style)
    val cw = sp.w * u
    val ch = sp.h * u
    val r = sp.r * u
    val base = size.height * 0.92f
    val top = base - ch
    val lidH = ch * sp.lid
    val seam = top + lidH
    val left = cx - cw / 2f
    val ext = st.extColor
    val lidC = st.lidColor
    val inner = Color(st.caseInt)
    val cg = st.caseGlossy

    // soft ground shadow
    scale(scaleX = 1f, scaleY = 0.16f, pivot = Offset(cx, base)) {
        drawCircle(
            Brush.radialGradient(listOf(Color.Black.copy(alpha = 0.42f), Color.Transparent), center = Offset(cx, base), radius = cw * 0.64f),
            radius = cw * 0.64f, center = Offset(cx, base)
        )
    }
    // glossy reflection on the surface below
    if (cg) {
        drawRect(
            Brush.verticalGradient(listOf(ext.copy(alpha = 0.28f), Color.Transparent), startY = base, endY = base + ch * 0.25f),
            topLeft = Offset(left + r * 0.4f, base), size = Size(cw - r * 0.8f, ch * 0.25f)
        )
    }

    val sil = Path().apply { addRoundRect(RoundRect(left, top, left + cw, base, CornerRadius(r, r))) }

    // lid, second half of the swing: we see its inside face leaning back above the case
    val t2 = ((open - 0.5f) * 2f).coerceIn(0f, 1f)
    if (t2 > 0f) {
        val up = lidH * 0.95f * t2
        val inset = cw * 0.03f
        val outer = Path().apply {
            addRoundRect(RoundRect(left + inset, top - up, left + cw - inset, top + lidH * 0.3f, CornerRadius(r * 0.9f, r * 0.9f)))
        }
        drawPath(outer, matBrush(lidC, cg, top - up, top))
        val inset2 = cw * 0.075f
        val face = Path().apply {
            addRoundRect(RoundRect(left + inset2, top - up + cw * 0.03f, left + cw - inset2, top + lidH * 0.3f, CornerRadius(r * 0.7f, r * 0.7f)))
        }
        drawPath(face, Brush.verticalGradient(listOf(inner.lighten(0.10f), inner.darken(0.25f)), startY = top - up, endY = top))
    }

    // cavity + earbuds
    if (open > 0f) {
        clipPath(sil) {
            clipRect(top = top, bottom = seam) {
                drawRect(
                    Brush.verticalGradient(listOf(inner.darken(0.35f), inner), startY = top, endY = seam),
                    topLeft = Offset(left, top), size = Size(cw, lidH)
                )
                for (sgn in listOf(-1f, 1f)) {
                    drawOval(
                        Color.Black.copy(alpha = 0.5f),
                        topLeft = Offset(cx + sgn * cw * 0.23f - cw * 0.09f, seam - cw * 0.07f),
                        size = Size(cw * 0.18f, cw * 0.06f)
                    )
                }
            }
        }
        if (open > 0.12f) {
            val ph = podHeight(st.style) * u
            val tipStart = seam + ph * 0.55f
            val tipEnd = top - u * 0.03f
            val tipY = mix(tipStart, tipEnd, rise.coerceIn(0f, 1f))
            clipRect(left = 0f, top = 0f, right = size.width, bottom = seam) {
                if (st.style == PodStyle.MAX) {
                    headphones(st.podColor.color, st.podGlossy, cx, tipY, u)
                } else {
                    pod(st.style, st.podColor.color, st.podGlossy, cx - cw * 0.23f, tipY, u, false)
                    pod(st.style, st.podColor.color, st.podGlossy, cx + cw * 0.23f, tipY, u, true)
                }
            }
        }
    }

    // body front
    clipPath(sil) {
        clipRect(top = seam, bottom = base) {
            drawRect(matBrush(ext, cg, seam, base), topLeft = Offset(left, seam), size = Size(cw, base - seam))
            if (cg) streak(left + cw * 0.10f, seam, cw * 0.35f, base - seam, 0.35f)
            if (st.style == PodStyle.MAX) {
                drawRoundRect(
                    Color.Black.copy(alpha = 0.18f),
                    topLeft = Offset(left + cw * 0.06f, seam + ch * 0.10f),
                    size = Size(cw * 0.88f, base - seam - ch * 0.20f),
                    cornerRadius = CornerRadius(r * 0.7f, r * 0.7f),
                    style = Stroke(width = u * 0.004f)
                )
            }
            drawLine(Color.Black.copy(alpha = 0.35f), Offset(left, seam), Offset(left + cw, seam), strokeWidth = u * 0.004f)
        }
    }
    // LED
    val ledC = Color(st.led)
    val ledAt = Offset(cx, seam + (base - seam) * 0.30f)
    drawCircle(Brush.radialGradient(listOf(ledC.copy(alpha = 0.55f), Color.Transparent), center = ledAt, radius = u * 0.035f), radius = u * 0.035f, center = ledAt)
    drawCircle(ledC, radius = u * 0.009f, center = ledAt)

    // lid front, first half of the swing
    val h = lidH * (1f - 2f * open).coerceAtLeast(0f)
    if (h > 1f) {
        clipPath(sil) {
            clipRect(top = top, bottom = top + h) {
                drawRect(matBrush(lidC, cg, top, seam), topLeft = Offset(left, top), size = Size(cw, lidH))
                if (cg) streak(left + cw * 0.10f, top, cw * 0.35f, lidH, 0.40f)
                drawLine(Color.Black.copy(alpha = 0.3f), Offset(left, top + h), Offset(left + cw, top + h), strokeWidth = u * 0.004f)
            }
        }
    }
    // rim light
    drawPath(sil, Color.White.copy(alpha = if (cg) 0.35f else 0.12f), style = Stroke(width = u * 0.004f))
}

private fun DrawScope.streak(x: Float, y: Float, w: Float, h: Float, a: Float) {
    drawRect(
        Brush.linearGradient(
            listOf(Color.Transparent, Color.White.copy(alpha = a), Color.Transparent),
            start = Offset(x, y), end = Offset(x + w, y + h * 0.3f)
        ),
        topLeft = Offset(x, y), size = Size(w, h)
    )
}

// ---------------------------------------------------------------------------------------------
// Earbuds (upright, stem down). tipY is the bottom of the stem.
// ---------------------------------------------------------------------------------------------

private fun DrawScope.pod(style: PodStyle, c: Color, glossy: Boolean, x: Float, tipY: Float, u: Float, right: Boolean) {
    val sgn = if (right) 1f else -1f
    rotate(7f * sgn, Offset(x, tipY)) {
        val sw: Float; val sh: Float; val hw: Float; val hh: Float; val cyk: Float
        when (style) {
            PodStyle.ORIGINAL -> { sw = 0.032f * u; sh = 0.140f * u; hw = 0.086f * u; hh = 0.098f * u; cyk = 0.38f }
            PodStyle.PRO -> { sw = 0.028f * u; sh = 0.085f * u; hw = 0.078f * u; hh = 0.070f * u; cyk = 0.30f }
            else -> { sw = 0.030f * u; sh = 0.090f * u; hw = 0.082f * u; hh = 0.080f * u; cyk = 0.32f }
        }
        val cy = tipY - sh - hh * cyk
        val stemBrush = Brush.horizontalGradient(
            listOf(c.darken(0.18f), c.lighten(if (glossy) 0.35f else 0.10f), c.darken(0.20f)),
            startX = x - sw / 2, endX = x + sw / 2
        )
        drawRoundRect(
            stemBrush, topLeft = Offset(x - sw / 2, tipY - sh), size = Size(sw, sh),
            cornerRadius = CornerRadius(if (style == PodStyle.ORIGINAL) sw / 2 else sw * 0.35f)
        )
        drawCircle(Color.Black.copy(alpha = 0.5f), radius = u * 0.0055f, center = Offset(x, tipY - sw * 0.8f))
        if (style != PodStyle.ORIGINAL) {
            drawLine(Color.Black.copy(alpha = 0.25f), Offset(x, tipY - sh * 0.62f), Offset(x, tipY - sh * 0.28f), strokeWidth = u * 0.004f)
        }
        if (style == PodStyle.PRO) {
            val tipC = lerp(c, Color.White, 0.78f)
            val tc = Offset(x - sgn * hw * 0.42f, cy - hh * 0.38f)
            drawOval(tipC, topLeft = Offset(tc.x - 0.023f * u, tc.y - 0.026f * u), size = Size(0.046f * u, 0.052f * u))
            drawCircle(Color.Black.copy(alpha = 0.35f), radius = u * 0.009f, center = tc)
        }
        drawOval(
            Brush.radialGradient(
                listOf(c.lighten(if (glossy) 0.45f else 0.14f), c, c.darken(0.30f)),
                center = Offset(x - hw * 0.15f, cy - hh * 0.2f), radius = hw * 0.8f
            ),
            topLeft = Offset(x - hw / 2, cy - hh / 2), size = Size(hw, hh)
        )
        val grille = if (style == PodStyle.GEN3) 0.20f else 0.16f
        drawCircle(Color.Black.copy(alpha = 0.55f), radius = hw * grille, center = Offset(x - sgn * hw * 0.20f, cy + hh * 0.10f))
        if (glossy) {
            drawOval(Color.White.copy(alpha = 0.45f), topLeft = Offset(x - hw * 0.32f, cy - hh * 0.40f), size = Size(hw * 0.26f, hh * 0.20f))
        }
    }
}

private fun DrawScope.headphones(c: Color, glossy: Boolean, cx: Float, bottom: Float, u: Float) {
    val cupW = 0.12f * u
    val cupH = 0.20f * u
    val gap = 0.17f * u
    val cupTop = bottom - cupH
    val bandTop = bottom - 0.34f * u
    val ctrl = cupTop + (bandTop - cupTop) / 0.75f
    val silver = Color(0xFFC9CCD1)
    val band = Path().apply {
        moveTo(cx - gap, cupTop + 0.01f * u)
        cubicTo(cx - gap, ctrl, cx + gap, ctrl, cx + gap, cupTop + 0.01f * u)
    }
    drawPath(band, c.shade(0.15f), style = Stroke(width = 0.036f * u, cap = StrokeCap.Round))
    drawPath(band, silver.copy(alpha = 0.65f), style = Stroke(width = 0.006f * u, cap = StrokeCap.Round))
    for (sgn in listOf(-1f, 1f)) {
        val x = cx + sgn * gap
        drawLine(silver, Offset(x, cupTop - 0.04f * u), Offset(x, cupTop + 0.02f * u), strokeWidth = 0.016f * u, cap = StrokeCap.Round)
        drawOval(
            Brush.radialGradient(
                listOf(c.lighten(if (glossy) 0.45f else 0.14f), c, c.darken(0.30f)),
                center = Offset(x - cupW * 0.1f, bottom - cupH * 0.65f), radius = cupH * 0.7f
            ),
            topLeft = Offset(x - cupW / 2, cupTop), size = Size(cupW, cupH)
        )
        val cushion = c.shade(0.35f)
        drawOval(
            cushion,
            topLeft = Offset(x - sgn * cupW * 0.28f - cupW * 0.275f, cupTop + cupH * 0.07f),
            size = Size(cupW * 0.55f, cupH * 0.86f)
        )
        if (glossy) {
            drawOval(Color.White.copy(alpha = 0.45f), topLeft = Offset(x - cupW * 0.3f, cupTop + cupH * 0.1f), size = Size(cupW * 0.22f, cupH * 0.18f))
        }
    }
}
