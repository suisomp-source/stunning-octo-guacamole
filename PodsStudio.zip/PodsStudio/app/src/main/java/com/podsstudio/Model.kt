package com.podsstudio

import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.flow.MutableStateFlow

enum class PodStyle(val label: String, val blurb: String) {
    ORIGINAL("Original AirPods", "2016 · long stems"),
    PRO("AirPods Pro", "Silicone tips"),
    GEN3("AirPods 3", "Short stems"),
    MAX("AirPods Max", "Over-ear")
}

enum class PodColor(val label: String, val argb: Long) {
    BLACK("Matte Black", 0xFF1C1C1E),
    WHITE("Pure White", 0xFFF5F5F3),
    GREY("Space Grey", 0xFF77787C),
    BLUE("Midnight Blue", 0xFF1F2D4D);

    val color: Color get() = Color(argb)
}

class Swatch(val name: String, val argb: Long)

val CASE_COLORS = PodColor.entries.map { Swatch(it.label, it.argb) }
val INTERIORS = listOf(
    Swatch("Black", 0xFF0E0E10), Swatch("White", 0xFFEDEDED), Swatch("Grey", 0xFF3A3A3D),
    Swatch("Blue", 0xFF101A2E), Swatch("Cream", 0xFFD8CDBB)
)
val LEDS = listOf(
    Swatch("Green", 0xFF34C759), Swatch("White", 0xFFFFFFFF), Swatch("Amber", 0xFFFF9F0A),
    Swatch("Blue", 0xFF0A84FF), Swatch("Off", 0xFF2A2A2A)
)

data class PodPrefs(
    val deviceAddress: String? = null,
    val deviceName: String? = null,
    val style: PodStyle = PodStyle.ORIGINAL,
    val podColor: PodColor = PodColor.BLACK,
    val podGlossy: Boolean = false,
    val matchCase: Boolean = true,
    val caseExt: Long = PodColor.BLACK.argb,
    val caseLid: Long = PodColor.BLACK.argb,
    val caseInt: Long = INTERIORS[0].argb,
    val led: Long = LEDS[0].argb,
    val caseGlossy: Boolean = false,
    val autoPopup: Boolean = true,
    val popupSecs: Int = 6,
    val animSpeed: Float = 1f,
    val theme: Int = 0,          // 0 system, 1 light, 2 dark
    val showBattery: Boolean = true,
    val notifications: Boolean = false
)

val PodPrefs.extColor: Color get() = if (matchCase) podColor.color else Color(caseExt)
val PodPrefs.lidColor: Color get() = if (matchCase) podColor.color else Color(caseLid)

/** Genuine live values only. Nothing here is ever invented: null means "not reported". */
object LiveState {
    val connected = MutableStateFlow(false)
    val battery = MutableStateFlow<Int?>(null)
    val source = MutableStateFlow<String?>(null)
}
