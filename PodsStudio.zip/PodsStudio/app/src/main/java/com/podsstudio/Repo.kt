package com.podsstudio

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.podStore by preferencesDataStore("pods_prefs")

private object K {
    val addr = stringPreferencesKey("addr")
    val name = stringPreferencesKey("name")
    val style = intPreferencesKey("style")
    val color = intPreferencesKey("color")
    val podGloss = booleanPreferencesKey("podGloss")
    val match = booleanPreferencesKey("match")
    val ext = longPreferencesKey("ext")
    val lid = longPreferencesKey("lid")
    val int = longPreferencesKey("int")
    val led = longPreferencesKey("led")
    val caseGloss = booleanPreferencesKey("caseGloss")
    val auto = booleanPreferencesKey("auto")
    val secs = intPreferencesKey("secs")
    val speed = floatPreferencesKey("speed")
    val theme = intPreferencesKey("theme")
    val showBat = booleanPreferencesKey("showBat")
    val notif = booleanPreferencesKey("notif")
}

class Repo(context: Context) {
    private val store = context.applicationContext.podStore

    val flow: Flow<PodPrefs> = store.data.map { read(it) }

    suspend fun update(f: (PodPrefs) -> PodPrefs) {
        store.edit { p -> write(p, f(read(p))) }
    }

    suspend fun resetCustomization() = update {
        val d = PodPrefs()
        it.copy(
            style = d.style, podColor = d.podColor, podGlossy = d.podGlossy, matchCase = d.matchCase,
            caseExt = d.caseExt, caseLid = d.caseLid, caseInt = d.caseInt, led = d.led, caseGlossy = d.caseGlossy
        )
    }

    private fun read(p: Preferences): PodPrefs {
        val d = PodPrefs()
        return PodPrefs(
            deviceAddress = p[K.addr],
            deviceName = p[K.name],
            style = PodStyle.entries.getOrElse(p[K.style] ?: 0) { d.style },
            podColor = PodColor.entries.getOrElse(p[K.color] ?: 0) { d.podColor },
            podGlossy = p[K.podGloss] ?: d.podGlossy,
            matchCase = p[K.match] ?: d.matchCase,
            caseExt = p[K.ext] ?: d.caseExt,
            caseLid = p[K.lid] ?: d.caseLid,
            caseInt = p[K.int] ?: d.caseInt,
            led = p[K.led] ?: d.led,
            caseGlossy = p[K.caseGloss] ?: d.caseGlossy,
            autoPopup = p[K.auto] ?: d.autoPopup,
            popupSecs = p[K.secs] ?: d.popupSecs,
            animSpeed = p[K.speed] ?: d.animSpeed,
            theme = p[K.theme] ?: d.theme,
            showBattery = p[K.showBat] ?: d.showBattery,
            notifications = p[K.notif] ?: d.notifications
        )
    }

    private fun write(p: MutablePreferences, s: PodPrefs) {
        val a = s.deviceAddress
        val n = s.deviceName
        if (a == null) p.remove(K.addr) else p[K.addr] = a
        if (n == null) p.remove(K.name) else p[K.name] = n
        p[K.style] = s.style.ordinal
        p[K.color] = s.podColor.ordinal
        p[K.podGloss] = s.podGlossy
        p[K.match] = s.matchCase
        p[K.ext] = s.caseExt
        p[K.lid] = s.caseLid
        p[K.int] = s.caseInt
        p[K.led] = s.led
        p[K.caseGloss] = s.caseGlossy
        p[K.auto] = s.autoPopup
        p[K.secs] = s.popupSecs
        p[K.speed] = s.animSpeed
        p[K.theme] = s.theme
        p[K.showBat] = s.showBattery
        p[K.notif] = s.notifications
    }
}
