package com.podsstudio

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.launch

enum class Screen { Welcome, Scanner, Pairing, Dashboard, Studio, CaseStudio, Preview, Battery, Devices, Settings }

class MainActivity : ComponentActivity() {
    private val navRequest = mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repo = Repo(this)
        navRequest.value = intent?.getStringExtra("screen")
        setContent { App(repo, navRequest) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        navRequest.value = intent.getStringExtra("screen")
    }
}

@Composable
fun App(repo: Repo, navRequest: MutableState<String?>) {
    val loaded by repo.flow.collectAsState(initial = null)
    val s = loaded
    if (s == null) {
        Box(Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black))
    } else {
        AppContent(repo, s, navRequest)
    }
}

@Composable
private fun AppContent(repo: Repo, s: PodPrefs, navRequest: MutableState<String?>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val upd: ((PodPrefs) -> PodPrefs) -> Unit = { f -> scope.launch { repo.update(f) } }

    var screen by rememberSaveable { mutableStateOf<Screen?>(null) }
    var pending by remember { mutableStateOf<Found?>(null) }

    val perms = arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.POST_NOTIFICATIONS)
    fun hasBt() = listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT).all {
        ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
    }
    var btOk by remember { mutableStateOf(hasBt()) }
    var overlayOk by remember { mutableStateOf(AndroidSettings.canDrawOverlays(ctx)) }
    var afterPerm by remember { mutableStateOf<(() -> Unit)?>(null) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        btOk = hasBt()
        if (btOk) afterPerm?.invoke()
        afterPerm = null
    }
    fun requestBt(then: () -> Unit) {
        if (hasBt()) then() else { afterPerm = then; permLauncher.launch(perms) }
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        overlayOk = AndroidSettings.canDrawOverlays(ctx)
        btOk = hasBt()
    }

    LaunchedEffect(Unit) {
        if (screen == null) screen = if (s.deviceAddress == null) Screen.Welcome else Screen.Dashboard
    }
    LaunchedEffect(navRequest.value) {
        if (navRequest.value == "battery" && s.deviceAddress != null) {
            screen = Screen.Battery
        }
        navRequest.value = null
    }
    LaunchedEffect(s.deviceAddress, btOk) {
        if (s.deviceAddress != null && btOk) {
            try { ContextCompat.startForegroundService(ctx, Intent(ctx, PodService::class.java)) } catch (_: Exception) {}
        }
    }

    BackHandler(enabled = screen != null && screen != Screen.Welcome && screen != Screen.Dashboard) {
        screen = if (s.deviceAddress == null) Screen.Welcome else Screen.Dashboard
    }

    PodsTheme(s.theme) {
        when (screen) {
            null -> Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background))
            Screen.Welcome -> WelcomeScreen(s) { requestBt { screen = Screen.Scanner } }
            Screen.Scanner -> ScannerScreen(
                onBack = { screen = if (s.deviceAddress == null) Screen.Welcome else Screen.Devices },
                onPick = { pending = it; screen = Screen.Pairing }
            )
            Screen.Pairing -> PairingScreen(
                dev = pending,
                onDone = { f ->
                    upd { it.copy(deviceAddress = f.address, deviceName = f.name ?: "Earbuds") }
                    screen = Screen.Dashboard
                },
                onBack = { screen = Screen.Scanner }
            )
            Screen.Dashboard -> DashboardScreen(
                s, go = { screen = it }, overlayOk = overlayOk,
                onGrantOverlay = {
                    ctx.startActivity(Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                }
            )
            Screen.Studio -> StudioScreen(s, upd, onBack = { screen = Screen.Dashboard }, onCase = { screen = Screen.CaseStudio })
            Screen.CaseStudio -> CaseStudioScreen(s, upd, onBack = { screen = Screen.Studio })
            Screen.Preview -> PreviewScreen(s, upd, onBack = { screen = Screen.Dashboard })
            Screen.Battery -> BatteryScreen(s, onBack = { screen = Screen.Dashboard })
            Screen.Devices -> DevicesScreen(
                s, upd, onBack = { screen = Screen.Dashboard },
                onAdd = { requestBt { screen = Screen.Scanner } },
                onForget = { ctx.stopService(Intent(ctx, PodService::class.java)); upd { it.copy(deviceAddress = null, deviceName = null) }; screen = Screen.Welcome }
            )
            Screen.Settings -> SettingsScreen(
                s, upd, repo, overlayOk, onBack = { screen = Screen.Dashboard }, onDevices = { screen = Screen.Devices },
                onGrantOverlay = {
                    ctx.startActivity(Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
                }
            )
        }
    }
}
