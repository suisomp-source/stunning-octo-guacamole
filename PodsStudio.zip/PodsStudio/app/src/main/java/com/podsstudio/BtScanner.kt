package com.podsstudio

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.UUID

data class Found(val name: String?, val address: String, val bonded: Boolean, val rssi: Int?)

/** Classic Bluetooth discovery using the public BluetoothAdapter API. */
@SuppressLint("MissingPermission")
class BtScanner(private val ctx: Context) {
    private val adapter: BluetoothAdapter? = ctx.getSystemService(BluetoothManager::class.java)?.adapter
    val found = MutableStateFlow<List<Found>>(emptyList())
    val scanning = MutableStateFlow(false)
    val supported get() = adapter != null
    val btOn get() = adapter?.isEnabled == true
    private var registered = false

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java) ?: return
                    val rssi = i.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE).toInt()
                    add(Found(d.name, d.address, d.bondState == BluetoothDevice.BOND_BONDED, if (rssi == Short.MIN_VALUE.toInt()) null else rssi))
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> scanning.value = false
            }
        }
    }

    private fun add(f: Found) {
        val cur = found.value.toMutableList()
        val idx = cur.indexOfFirst { it.address == f.address }
        if (idx >= 0) {
            val old = cur[idx]
            cur[idx] = f.copy(name = f.name ?: old.name, rssi = f.rssi ?: old.rssi)
        } else cur.add(f)
        found.value = cur.sortedWith(compareBy<Found> { it.name == null }.thenByDescending { it.rssi ?: -200 })
    }

    fun start() {
        val a = adapter ?: return
        if (!a.isEnabled) return
        if (!registered) {
            val f = IntentFilter().apply {
                addAction(BluetoothDevice.ACTION_FOUND)
                addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            }
            ctx.registerReceiver(rx, f, Context.RECEIVER_EXPORTED)
            registered = true
        }
        found.value = emptyList()
        a.bondedDevices?.forEach { add(Found(it.name, it.address, true, null)) }
        a.cancelDiscovery()
        scanning.value = a.startDiscovery()
    }

    fun stop() {
        try { adapter?.cancelDiscovery() } catch (_: Exception) {}
        if (registered) {
            try { ctx.unregisterReceiver(rx) } catch (_: Exception) {}
            registered = false
        }
        scanning.value = false
    }
}

/** Reads the standard BLE Battery Service (0x180F) if the earbuds expose it. Most generic earbuds do not. */
@SuppressLint("MissingPermission")
class GattBattery(private val ctx: Context, private val onLevel: (Int) -> Unit) {
    private var gatt: BluetoothGatt? = null
    private val svc = UUID.fromString("0000180f-0000-1000-8000-00805f9b34fb")
    private val chr = UUID.fromString("00002a19-0000-1000-8000-00805f9b34fb")

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
            else if (newState == BluetoothProfile.STATE_DISCONNECTED) g.close()
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val c = g.getService(svc)?.getCharacteristic(chr)
            if (c != null) g.readCharacteristic(c) else g.disconnect()
        }

        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS && value.isNotEmpty()) onLevel(value[0].toInt() and 0xFF)
            g.disconnect()
        }
    }

    fun start(d: BluetoothDevice) {
        stop()
        if (d.type == BluetoothDevice.DEVICE_TYPE_CLASSIC) return
        gatt = d.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
    }

    fun stop() {
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
    }
}
