# Pods Studio (Kotlin · Jetpack Compose)

AirPods-style connection popup, customization studio and battery screen for a Samsung Galaxy S25 + generic S18 Pro earbuds.

## Build the APK (Android Studio, ~5 min)
1. Install Android Studio (Ladybug or newer). Open this folder (`PodsStudio`). If asked, use Gradle 8.9 and JDK 17 (bundled).
2. Wait for Gradle sync (needs internet once, to download dependencies).
3. Menu: Build > Build App Bundle(s) / APK(s) > Build APK(s).
   APK: `app/build/outputs/apk/debug/app-debug.apk`
   (Or: `./gradlew assembleRelease` -> `app/build/outputs/apk/release/app-release.apk`, signed with the debug key for personal use.)

## Install on the S25
- Easiest: enable Developer options + USB debugging, plug in, press Run in Android Studio.
- Or copy the APK to the phone, open it, allow "Install unknown apps" for your file manager, install.

## First-run setup
1. Open the app > Add New Earbuds > allow Bluetooth + notification permissions.
2. Put the S18 Pro in pairing mode, pick it in the list, confirm Android's pairing dialog.
3. Dashboard > "Grant permission" to allow display over other apps (needed for the floating card).
4. Samsung: Settings > Apps > Pods Studio > Battery > Unrestricted, so the watcher service is not put to sleep.

## Honest limitations
- The case sends no Bluetooth signal, so the popup fires when the earbuds connect; the case opening is only an animation.
- Battery: Android exposes at most what the earbuds report (BLE battery service, Android's Bluetooth battery broadcast, or the headset "+IPHONEACCEV" report). Generic earbuds usually give one combined number or nothing. Left/right/case show "—" unless reported. Nothing is estimated.
- Pairing uses Android's system pairing dialog (BluetoothDevice.createBond). "Forget" removes the device from this app; unpair fully in Android Bluetooth settings.
- Illustrations are original, drawn in code (Compose Canvas), no stock images.
- This source was written without being compiled in the authoring environment, so a small compile error may need fixing: paste it back and it can be corrected quickly.

## Build WITHOUT Android Studio (GitHub, free, no install)
1. Create a free account at github.com and make a new repository (private is fine).
2. Upload everything in this folder (including the hidden `.github` folder) via "Add file > Upload files".
3. Open the Actions tab; the "Build APK" run starts automatically (about 5 minutes).
4. Open the finished run, download the `PodsStudio-apk` artifact, unzip it, copy `app-debug.apk` to your S25 and install it.
